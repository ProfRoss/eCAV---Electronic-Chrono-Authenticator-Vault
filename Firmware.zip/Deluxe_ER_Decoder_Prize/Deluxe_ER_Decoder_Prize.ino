/********************************************************************
   Created by A/Prof Robert Ross 2026
   Contact details: R.Ross@latrobe.edu.au
   Note: In a fresh install of the Arduino software the keymatix library needs to be added (Sketch->Include Library ->Manage Libraries->search for KeyMatrix
 
    ****To open the compartment hold down the zero key on the keypad as you switch the device on with the key switch ****
*/
#include <Wire.h>
#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>
#include <EEPROM.h>
#include <KeyMatrix.h>
#include <KeyMatrixPhone.h>
#include "pitches.h"
#include <avr/wdt.h>

U8G2_SSD1309_128X64_NONAME0_1_HW_I2C OLED(U8G2_R0, U8X8_PIN_NONE);

/*
  Modify these parts to setup a new escape room
*/
int giveClues = 1;                          // If 1 clues will be given (every 5 minutes stuck in a round), if 0 no clues will be given
int wrongAnswerPenalty = 1;                 // Number of minutes to penalise teams for wrong answer (0 = no penalty, 1 = 1 minute penalty)
static volatile int countDownClock = 2700;  // Game Time in seconds (3300 = 55 minutes, 2700 = 45 minutes)
String Key1 = "01234";                      // Answer for Puzzle 1 (between 1 and 8 digits)
String Key2 = "456";                        // Answer for Puzzle 2 (between 1 and 8 digits)
String Key3 = "12345678";                   // Answer for Puzzle 3 (between 1 and 8 digits)

/*
  End of code for user to modify. Don't modify code below this line
*/

int timeInRound = countDownClock;

int stateCounter = 1;
int currDigit = 1;  //The digit we are trying to enter
int old_currDigit = 1;
int enteringCodeFlag = 0;  //If we have started entering the code set flag to 1 (prevents X's from overwriting digits)
String codeString = "        ";
int screenUpdateFlag = 1;

//SoundFX
int melody_fail[] = {
  NOTE_G3, NOTE_C3
};

//SoundFX
int melody_succeed[] = {
  NOTE_C3, NOTE_C4, NOTE_C5, NOTE_C6
};

int melody_clue[] = {
  NOTE_E6, NOTE_E6
};

//SoundFX
// note durations: 4 = quarter note, 8 = eighth note, etc.:
int noteDurationsFail[] = {
  2, 1
};

//SoundFX
int noteDurationsSucceed[] = {
  8, 8, 8, 8
};

//SoundFX
int noteDurationsClue[] = {
  8, 8
};

int lockPin = 2;
AK_304(keypad, 6, 7, 8, 9, 10, 11, 12);

int readKeypad(void);
void updateOLED(void);
void setupCountDownTimer(void);
void OLED_Startup_Displays(char startup);
int getRemainingStringLen(void);
int validateKey(void);
void playSFXFail(void);
void playSFXSucceed(void);
void playSFXClue(void);
void playSFXWIN(void);
String getCurrKey(void);
void updatePartialCodeStringWithClues(void);

void setup() {
  char keyPadValue;
  wdt_disable();
  Serial.begin(9600);
  pinMode(lockPin, OUTPUT);
  digitalWrite(lockPin, HIGH);
  delay(250);  // wait for the OLED to power up
  codeString = "";
  OLED.begin();
  setupCountDownTimer();

  keyPadValue = readKeypad();
  if (keyPadValue == '0') {  //Open Vault (for storing prizes)
    OLED_Startup_Displays('0');
    digitalWrite(lockPin, LOW);  //Unlock Latch
    delay(400);
    digitalWrite(lockPin, HIGH);
    while (1) {}
  }
}

void loop() {
  char keyPadValue;

  while (1) {
    delay(50);
    if(1 == screenUpdateFlag){  //Only update screen when something has changed
      updateOLED();
      screenUpdateFlag = 0;
    }
    
    keyPadValue = readKeypad();
    if('X' != keyPadValue){ //Set screen to update on button press
      screenUpdateFlag = 1;
    }
    
    if (4 == stateCounter) {
      playSFXWIN();
      digitalWrite(lockPin, LOW);
      delay(400);
      digitalWrite(lockPin, HIGH);
      while (1) {}
    }

    if (0 == countDownClock) {
      playSFXFail();
      playSFXFail();
      playSFXFail();
      while (1) {}
    }

    if (keyPadValue == '*') {  //'*' pressed - clear display
      currDigit = 1;           //
      old_currDigit = 1;       //
      enteringCodeFlag = 0;    //Clear flag - back to no partial answer being entered
      codeString = "";         //Clear temp string that was being entered
    } else {
      if (0 == enteringCodeFlag) {                       //Haven't started trying to enter a code
        if (1 == giveClues) {                            //Clues should be delivered every 5 minutes
          int timeStuck = timeInRound - countDownClock;  //Seconds stuck for - every 300 seconds (5 min) gives a new clue
          currDigit = (timeStuck / 300) + 1;                       
        }

        int keyLength = getCurrKey().length();
        if (currDigit > keyLength) {  // Check that we are not giving away the final digit of any puzzle
          currDigit = keyLength;      // Trim so that the final digit is never given away
        }
        codeString = getCurrKey().substring(0, currDigit - 1);
        if (currDigit != old_currDigit) {  //Check if a new clue has just been given and if so play soundFX beep-beep
          old_currDigit = currDigit;
          playSFXClue();
        }
      }
      if (keyPadValue != 'X') {
        enteringCodeFlag = 1;               //User has started to enter code
        codeString += keyPadValue;          //Add to the code
        currDigit++;                        //Allow user to enter next digit
        if (getRemainingStringLen() < 1) {  //Need to validate solution - correct number of digits have been entered
          if (1 == validateKey()) {
            updateOLED();
            stateCounter++;
            playSFXSucceed();
            codeString = "";
            currDigit = 1;
            old_currDigit = 1;
            enteringCodeFlag = 0;
            timeInRound = countDownClock;  //Reset clue timer for new round
          } else {
            updateOLED();
            playSFXFail();
            if (countDownClock > (60*wrongAnswerPenalty)) {
              countDownClock -= (60*wrongAnswerPenalty);
            } else {
              countDownClock = 0;
            }
          }
          codeString = "";       // Clear code that was being entered
          currDigit = 1;         // Back to first digit that needs to be entered
          enteringCodeFlag = 0;  // Clear flag - back to no partial answer being entered
        }
      }
    }
  }
}


void OLED_Startup_Displays(char startup) {
  if ('0' == startup) {
    OLED.firstPage();
    do {
      OLED.setFont(u8g2_font_ncenB08_tr);
      OLED.drawStr(5, 10, "Unlocking Vault:");
    } while (OLED.nextPage());
  }

  if ('1' == startup) {
    OLED.firstPage();
    do {
      OLED.setFont(u8g2_font_ncenB08_tr);
      OLED.drawStr(5, 10, "Change Solutions");
    } while (OLED.nextPage());
  }

  if ('2' == startup) {
    OLED.firstPage();
    do {
      OLED.setFont(u8g2_font_ncenB08_tr);
      OLED.drawStr(5, 10, "Change Settings");
    } while (OLED.nextPage());
  }
}

void updateOLED(void) {
  OLED.firstPage();
  do {
    OLED.setFont(u8g2_font_ncenB08_tr);
    OLED.drawStr(5, 10, "Chrono Authenticator");
    OLED.drawLine(0, 15, 128, 15);
    OLED.drawStr(5, 27, "Puzzle");
    OLED.drawStr(62, 27, "Time");
    OLED.setCursor(46, 27);
    if (stateCounter < 4) {
      OLED.print(stateCounter);
    }

    OLED.setCursor(95, 27);
    OLED.print((countDownClock / 600));
    OLED.print((countDownClock / 60) % 10);
    OLED.print(":");
    OLED.print(((countDownClock % 60) / 10));
    OLED.print((countDownClock % 10));

    if (4 == stateCounter) {
      OLED.setCursor(20, 47);
      OLED.print(" Congratulations");
      OLED.setCursor(20, 58);
      OLED.print("Mission Success!");
    }

    if (0 == countDownClock) {
      OLED.setCursor(38, 47);
      OLED.println("Game Over");
      OLED.setCursor(10, 58);
      OLED.print("Better luck next time");
    }

    if ((4 != stateCounter) && (0 != countDownClock)) {
      OLED.setCursor(40, 50);
      OLED.print(codeString);
      for (int i = 0; i < getRemainingStringLen(); i++) {
        OLED.print('*');
      }
    }

  } while (OLED.nextPage());
}

int getRemainingStringLen(void) {
  int currLength = codeString.length();
  if (1 == stateCounter) {
    return (Key1.length() - currLength);
  }

  if (2 == stateCounter) {
    return (Key2.length() - currLength);
  }

  if (3 == stateCounter) {
    return (Key3.length() - currLength);
  }
}

void updatePartialCodeStringWithClues(void) {
  if (1 == stateCounter) {
    codeString = Key1.substring(0, currDigit);
  }

  if (2 == stateCounter) {
    codeString = Key2.substring(0, currDigit);
  }

  if (3 == stateCounter) {
    codeString = Key3.substring(0, currDigit);
  }
}

int validateKey(void) {
  if (1 == stateCounter) {
    if (codeString == Key1) {
      return 1;
    } else {
      return 0;
    }
  }

  if (2 == stateCounter) {
    if (codeString == Key2) {
      return 1;
    } else {
      return 0;
    }
  }

  if (3 == stateCounter) {
    if (codeString == Key3) {
      return 1;
    } else {
      return 0;
    }
  }
}

int readKeypad(void) {
  if (keypad.pollEvent()) {
    // event data is stored on keypad.event
    if (keypad.event.type == KM_KEYDOWN) {
      tone(3, NOTE_C4, 50);
      return keypad.event.c;
    }
  }
  return 'X';
}

void setupCountDownTimer(void) {
  //Uses timer 1 (16MHz) to generate a 1 second interrupt to count down.
  //Use CTC mode (Clear Timer on Compare Match with OCR1A)
  TCCR1A = 0x00;  // Normal port operation, Waveform Generation Mode 4 (CTC)
  TCCR1B = 0x0C;  // CTC mode active (WGM12=1), Prescaler set to 256 (CS12=1)
  TCNT1 = 0;      // Initialize counter value to 0
  OCR1A = 62499;  // 62499 = exactly 1 second interval at 16MHz
  TIMSK1 = 0x02;  // Enable Timer 1 Output Compare A Match Interrupt
}

ISR(TIMER1_COMPA_vect) {  //Timer is triggered every 1 second
  if (countDownClock != 0) {
    countDownClock--;
    screenUpdateFlag = 1;
  }
}

void playSFXClue(void) {
  for (int thisNote = 0; thisNote < 2; thisNote++) {
    int noteDuration = 1000 / noteDurationsClue[thisNote];
    tone(3, melody_clue[thisNote], noteDuration);
    int pauseBetweenNotes = noteDuration * 1.30;
    delay(pauseBetweenNotes);
    // stop the tone playing:
    noTone(3);
  }
}


void playSFXFail(void) {
  for (int thisNote = 0; thisNote < 2; thisNote++) {
    int noteDuration = 1000 / noteDurationsFail[thisNote];
    tone(3, melody_fail[thisNote], noteDuration);
    int pauseBetweenNotes = noteDuration * 1.30;
    delay(pauseBetweenNotes);
    // stop the tone playing:
    noTone(3);
  }
}


void playSFXSucceed(void) {
  for (int thisNote = 0; thisNote < 4; thisNote++) {
    int noteDuration = 1000 / noteDurationsSucceed[thisNote];
    tone(3, melody_succeed[thisNote], noteDuration);
    int pauseBetweenNotes = noteDuration * 1.30;
    delay(pauseBetweenNotes);
    // stop the tone playing:
    noTone(3);
  }
}

void playSFXWIN() {
  int run[] = { NOTE_C5, NOTE_D5, NOTE_E5, NOTE_F5, NOTE_G5, NOTE_A5, NOTE_B5, NOTE_C6 };

  for (int i = 0; i < 8; i++) {
    tone(3, run[i], 60);
    delay(60);
  }

  tone(3, NOTE_C6, 400);
  delay(400);
  tone(3, NOTE_G6, 500);
  delay(500);
  noTone(3);
}

String getCurrKey(void) {  //Returns the key string corresponding to the current round that you are trying to solve
  if (1 == stateCounter)
    return Key1;
  if (2 == stateCounter)
    return Key2;
  if (3 == stateCounter)
    return Key3;
}
